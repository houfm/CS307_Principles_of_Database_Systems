import java.sql.*;

public class DatabaseAdvancedManipulation {
    private Connection con = null;
    private ResultSet resultSet;

    private String host = "localhost";
    private String dbname = "postgres";
    private String user = "test";
    private String pwd = "123456";
    private String port = "5432";


    private void getConnection() {
        try {
            Class.forName("org.postgresql.Driver");

        } catch (Exception e) {

            System.err.println("Cannot find the PostgreSQL driver. Check CLASSPATH.");
            System.exit(1);
        }

        try {
            String url = "jdbc:postgresql://" + host + ":" + port + "/" + dbname;
            con = DriverManager.getConnection(url, user, pwd);

        } catch (SQLException e) {
            System.err.println("Database connection failed");
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }


    private void closeConnection() {
        if (con != null) {
            try {
                con.close();
                con = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void q2() {
        long start;
        long end;
        start = System.currentTimeMillis();
        getConnection();
        StringBuilder stringBuilder = new StringBuilder();
        String sql = "select T2.name, T2.Courier_City, T2.Company_Name\n" +
                "from (select A.Courier_Name name, count(*) count, Courier_City, Company_Name\n" +
                "      from Delivery_Courier A\n" +
                "               join Delivery B on A.Courier_Name = B.Delivery_Courier\n" +
                "      group by Courier_City, Company_Name, A.Courier_Name) T2\n" +
                "         join (select max(count) max, Courier_City, Company_Name\n" +
                "               from (select  count(*) count, Courier_City, Company_Name\n" +
                "                     from Delivery_Courier A\n" +
                "                              join Delivery B on A.Courier_Name = B.Delivery_Courier\n" +
                "                     group by Courier_City, Company_Name, A.Courier_Name) T1\n" +
                "               group by Company_Name, Courier_City) T3\n" +
                "              on (T2.Company_Name = T3.Company_Name and T2.Courier_City = T3.Courier_City)\n" +
                "where T2.count = T3.max";
        try {
            Statement statement = con.createStatement();
            resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                for (int i = 1; i < 3; i++) {
                    stringBuilder.append(resultSet.getString(i)).append(",");
                }
                stringBuilder.append(resultSet.getString(3)).append("\n");

            }
            end = System.currentTimeMillis();
            System.out.println(stringBuilder);
            System.out.println(end - start + "ms");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }

    }

    public void q3() {
        long start;
        long end;
        start = System.currentTimeMillis();
        getConnection();
        StringBuilder stringBuilder = new StringBuilder();
        String sql = "select Export_City, sum(taxRate * B.sum) summary\n" +
                "from (select distinct Item_Class, Export_City, taxRate\n" +
                "      from (select Item_Class,\n" +
                "                   Item_Price,\n" +
                "                   Export_Tax,\n" +
                "                   Export_City,\n" +
                "                   round(cast(Export_Tax / Item_Price as numeric), 8) taxRate\n" +
                "            from (select Item_Class, Item_Name, Item_Price, Export_City, Export_Tax, Retrieval_Courier\n" +
                "                  from (select Item_Class, Item_Name, Item_Price, E.Export_Tax, E.Export_City\n" +
                "                        from item\n" +
                "                                 join Export E on Item_A.Item_Name = E.Export_Item) T1\n" +
                "                           join Retrieval on Item_Name = Retrieval.Retrieval_Item) T2\n" +
                "                     join Retrieval_Courier on T2.Retrieval_Courier = Retrieval_Courier.Courier_Name\n" +
                "            where Company_Name = 'Amazon.com') T) A\n" +
                "         join (select Item_Class, sum(Item_Price) sum\n" +
                "               from (select Item_Name, Item_Class, Item_Price, Retrieval_Courier\n" +
                "                     from item\n" +
                "                              join Retrieval R on Item_A.Item_Name = R.Retrieval_Item) T\n" +
                "                        join Retrieval_Courier on T.Retrieval_Courier = Retrieval_Courier.Courier_Name\n" +
                "               where Company_Name = 'Amazon.com'\n" +
                "               group by Item_Class) B on A.Item_Class = B.Item_Class\n" +
                "group by Export_City\n" +
                "order by summary\n" +
                "limit 1";
        try {
            Statement statement = con.createStatement();
            resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                stringBuilder.append(resultSet.getString(1)).append(",").append(resultSet.getString(2)).append("\n");

            }
            end = System.currentTimeMillis();
            System.out.println(stringBuilder);
            System.out.println(end - start + "ms");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
    }
}
