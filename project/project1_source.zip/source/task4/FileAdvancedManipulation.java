import java.io.*;
import java.util.Objects;

public class FileAdvancedManipulation {
    public void q2() {
        String input1_name = "delivery_courier.csv";
        String input2_name = "retrieval_courier.csv";
        String current_line;
        int n = 500000;
        String[] lines = new String[n];
        String[][] lines_split = new String[n][6];
        q1Group[] groups = new q1Group[n];
        int index_of_company_name = 5;
        int index_of_courier_city = 4;
        int index_of_courier_name = 0;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(input1_name));
            current_line = reader.readLine();
            int i = 0;
            while ((current_line = reader.readLine()) != null) {
                lines[i] = current_line;
                lines_split[i] = current_line.split(",");
                i++;
            }

            int max_index_of_group = -1;
            first:
            for (int j = 0; j < n; j++) {
                second:
                for (int k = 0; k < max_index_of_group; k++) {
                    if (Objects.equals(groups[k].city, lines_split[j][index_of_courier_city])
                    && Objects.equals(groups[k].company, lines_split[j][index_of_company_name])
                    && Objects.equals(groups[k].courier_name, lines_split[j][index_of_courier_name])){
                        groups[k].cnt++;
                        continue first;
                    }
                }
                max_index_of_group++;
                groups[max_index_of_group] = new q1Group(lines_split[j][index_of_courier_city],
                        lines_split[j][index_of_company_name],lines_split[j][index_of_courier_name]);
                groups[max_index_of_group].cnt++;
            }

            q1Group[] max = new q1Group[501000];
            int max_index_of_max=-1;
            first:
            for (int j = 0; j < max_index_of_group; j++) {
                for (int k = 0; k < max_index_of_max; k++) {
                    if (Objects.equals(groups[j].city, max[k].city)
                    && Objects.equals(groups[j].company, max[k].company)){
                        if (groups[j].cnt > max[k].cnt){
                            max[k].courier_name = groups[j].courier_name;
                            max[k].cnt = groups[j].cnt;
                            continue first;
                        }
                    }
                }

                max_index_of_max++;
                max[max_index_of_max] = new q1Group(groups[j].city,groups[j].company,groups[j].courier_name,groups[j].cnt);
            }

            StringBuilder sb = new StringBuilder();
            sb.append(String.format("%-10s","courier_name"));
            sb.append(String.format("%-15s","courier_city"));
            sb.append("company_name");
            System.out.println(sb);
            sb.setLength(0);

            for (int j = 0; j < max_index_of_max; j++) {
                sb.append(String.format("%-10s",max[j].courier_name));
                sb.append(String.format("%-15s",max[j].city));
                sb.append(max[j].company);
                System.out.println(sb);
                sb.setLength(0);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void q3(){
        int n =500000;
        q2Group[] groups = new q2Group[n];

        try {
            BufferedReader reader1 = new BufferedReader(new FileReader("item.csv"));
            BufferedReader reader2 = new BufferedReader(new FileReader("export.csv"));
            BufferedReader reader3 = new BufferedReader(new FileReader("retrieval_courier.csv"));
            String current_line;

            String[] split;
            current_line = reader1.readLine();
            for (int i = 0; i < n; i++) {
                current_line = reader1.readLine();
                split = current_line.split(",");
                groups[i] = new q2Group(split[0], Double.parseDouble(split[1]),split[2]);
            }

            current_line = reader2.readLine();
            for (int i = 0; i < n; i++) {
                current_line = reader2.readLine();
                split = current_line.split(",");
                groups[i].tax = Double.parseDouble(split[1]);
            }
            current_line = reader3.readLine();
            for (int i = 0; i < 1610; i++) {
                current_line = reader3.readLine();
                split = current_line.split(",");
                groups[i].city = split[4];
                groups[i].company = split[5];
            }

            taxGroup[] taxGroups = new taxGroup[n];
            int max_index_tax = -1;
            first:
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < max_index_tax; j++) {
                    if (Objects.equals(groups[i].city, taxGroups[j].city)
                    && Objects.equals(groups[i].item_class, taxGroups[j].item_class)){
                        continue first;
                    }
                }
                max_index_tax++;
                taxGroups[max_index_tax] = new taxGroup(groups[i].item_class,groups[i].city,
                        groups[i].tax / groups[i].price);


            }

            int max_index_price = -1;
            priceGroup[] priceGroups = new priceGroup[n];
            first:
            for (int i = 0; i < n; i++) {
                if (groups[i].company.equals("Amazon.com")){
                    for (int j = 0; j < max_index_price; j++) {
                        if (Objects.equals(groups[i].item_class, priceGroups[j].item_class)){
                            priceGroups[j].price+=groups[i].price;
                            continue first;
                        }
                    }
                    max_index_price++;
                    priceGroups[max_index_price] = new priceGroup(groups[i].item_class,groups[i].price);
                }
            }
            

            first:
            for (int i = 0; i < max_index_tax; i++) {
                for (int j = 0; j < max_index_price; j++) {
                    if (Objects.equals(priceGroups[j].item_class, taxGroups[i].item_class)) {
                        taxGroups[i].tax_of_certain_item = priceGroups[j].price * taxGroups[i].tax_rate;
                        continue first;
                    }
                }
            }

            int max_index_city = -1;
            cityGroup[] cityGroups = new cityGroup[n];
            first:
            for (int i = 0; i < max_index_tax; i++) {
                for (int j = 0; j < max_index_city; j++) {
                    if (cityGroups[j].city.equals(taxGroups[i].city)) {
                        cityGroups[j].tax+=taxGroups[i].tax_of_certain_item;
                        continue first;
                    }
                }
                max_index_city++;
                cityGroups[max_index_city] = new cityGroup(taxGroups[i].tax_of_certain_item,taxGroups[i].city);
            }

            double max = 0;
            String city = " ";
            for (int i = 0; i < max_index_city; i++) {
                if (cityGroups[i].tax > max){
                    max = cityGroups[i].tax;
                    city = cityGroups[i].city;
                }
            }
            System.out.println(max);
            System.out.println(city);

        } catch (IOException e){
            e.printStackTrace();
        }
    }
}

class q1Group {
    String city;
    String company;
    String courier_name;
    int cnt;

    public q1Group(String city, String company, String name) {
        this.city = city;
        this.company = company;
        this.courier_name = name;
        cnt = 0;
    }

    public q1Group(String city, String company, String courier_name, int cnt) {
        this.city = city;
        this.company = company;
        this.courier_name = courier_name;
        this.cnt = cnt;
    }

    public void add() {
        ++cnt;
    }
}

class q2Group{
    String item_name;
    double price;
    String item_class;

    double tax;
    String city;

    String company;
    public q2Group(String item_name, double price, String item_class) {
        this.item_name = item_name;
        this.price = price;
        this.item_class = item_class;
    }
}

class taxGroup{
    String item_class;
    String city;
    double tax_rate;
    double tax_of_certain_item;

    public taxGroup(String item_class, String city, double tax_rate) {
        this.item_class = item_class;
        this.city = city;
        this.tax_rate = tax_rate;
    }
}

class priceGroup{
    String item_class;
    double price;

    public priceGroup(String item_class, double price) {
        this.item_class = item_class;
        this.price = price;
    }
}

class cityGroup{
    double tax = 0;
    String city;

    public cityGroup(double tax, String city) {
        this.tax = tax;
        this.city = city;
    }
}