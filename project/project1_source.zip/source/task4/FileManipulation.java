import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.stream.Collectors;

// methods to read csv(comma separated values) file:
// Scanner File useDelimiter
// BufferedReader split
// FileReader split

public class FileManipulation extends DatabaseManipulation {
    public void insert_test_output_file() {
        String input_name = "delivery.csv";
        String output_name = "output.csv";
        int test_number = 10000;
        String[] lines = new String[501000];
        int[] used = new int[501000];
        String current_line;
        Random random = new Random();
        int index;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(input_name));
            int i=0;
            while ((current_line = reader.readLine()) != null){
                lines[i] = current_line;
                i++;
            }
            BufferedWriter writer = new BufferedWriter(new FileWriter(output_name));
            writer.write(lines[0]);
            writer.newLine();
            for (int j = 0; j < test_number; j++) {
                index = random.nextInt(500000)+1;
                while (used[index] == 1){
                    index = random.nextInt(500000)+1;
                }
                writer.write(lines[index]);
                used[index] =1;
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void insert_test() {
        String input_name = "delivery.csv";
        int test_number = 10000;
        String[] lines = new String[501000];
        int[] used = new int[501000];
        String current_line;
        Random random = new Random();
        int index;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(input_name));
            int i=0;
            while ((current_line = reader.readLine()) != null){
                lines[i] = current_line;
                i++;
            }
            System.out.println(lines[0]);
            for (int j = 0; j < test_number; j++) {
                index = random.nextInt(500000)+1;
                while (used[index] == 1){
                    index = random.nextInt(500000)+1;
                }
//                writer.write(lines[index]);
                System.out.println(lines[index]);
                used[index] =1;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void delete_test() {
        String input_name = "delivery.csv";
        String remove = "";
        int[] used = new int[500010];
        int index_of_time = 2;
        String current_line;
        String[] splitArray;
        Random random = new Random();
        int index;
        try {
            for (int i = 0; i < 10000; i++) {
                index = random.nextInt(500000)+1;
                while (used[index] == 1){
                    index = random.nextInt(500000)+1;
                }
                used[index] =1;
            }
            BufferedReader reader = new BufferedReader(new FileReader(input_name));
            current_line = reader.readLine();
            while ((current_line = reader.readLine()) != null) {
                splitArray = current_line.split(",");
                if (used[Integer.parseInt(splitArray[0])] != 1) {
//                    writer.write(current_line);
//                    writer.newLine();
                    System.out.println(current_line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void delete_test_file() {
        String input_name = "delivery.csv";
        String output_name = "output.csv";
        String remove = "";
        int index_of_time = 2;
        String current_line;
        String[] splitArray;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(input_name));
            BufferedWriter writer = new BufferedWriter(new FileWriter(output_name));
            while ((current_line = reader.readLine()) != null) {
                splitArray = current_line.split(",");
                if (splitArray[index_of_time] != remove) {
                    writer.write(current_line);
                    writer.newLine();
                }
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void delete_test2(String lineContent) throws IOException {
        // need modify
        File file = new File("myFile.txt");
        List<String> out = Files.lines(file.toPath())
                .filter(line -> !line.contains(lineContent))
                .collect(Collectors.toList());
        Files.write(file.toPath(), out, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);

    }

    public void update_test() {
        String current_line;
        String input_name = "delivery.csv";
//        String output_name = "output.csv";
        int index_of_delivery_finish_time = 2;
        Random rad = new Random();
        String[] splitArray;
        try {
            BufferedReader reader1 = new BufferedReader(new FileReader(input_name));
            BufferedReader reader2 = new BufferedReader(new FileReader(input_name));
//            BufferedWriter writer = new BufferedWriter(new FileWriter(output_name));
            while ((current_line = reader1.readLine()) != null) {
                splitArray = current_line.split(",");
                if (splitArray[index_of_delivery_finish_time] != "") {
                    // or null?
//                    writer.write(current_line);
//                    writer.newLine();
                    System.out.println(current_line);
                }
            }
            while ((current_line = reader2.readLine()) != null) {
                splitArray = current_line.split(",");
                if (splitArray[index_of_delivery_finish_time] == "") {
                    // or null?
                    StringBuilder sb = new StringBuilder();
                    int n = splitArray.length;
                    splitArray[2] = String.valueOf(rad.nextInt(100)+1);
                    splitArray[3] = String.valueOf(rad.nextInt(100)+1);
                    for (int i = 0; i < n-1; i++) {
                        sb.append(splitArray[i]);
                        sb.append(",");
                    }
                    sb.append(splitArray[n-1]);
//                    writer.write(sb.toString());
//                    writer.newLine();
                    System.out.println(sb.toString());
                }
            }
//            writer.close();
            reader2.close();
            reader1.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void update_test_file() {
        String current_line;
        String input_name = "delivery.csv";
        String output_name = "output.csv";
        int index_of_delivery_finish_time = 2;
        Random rad = new Random();
        String[] splitArray;
        try {
            BufferedReader reader1 = new BufferedReader(new FileReader(input_name));
            BufferedReader reader2 = new BufferedReader(new FileReader(input_name));
            BufferedWriter writer = new BufferedWriter(new FileWriter(output_name));
            while ((current_line = reader1.readLine()) != null) {
                splitArray = current_line.split(",");
                if (splitArray[index_of_delivery_finish_time] != "") {
                    // or null?
                    writer.write(current_line);
                    writer.newLine();
                }
            }
            while ((current_line = reader2.readLine()) != null) {
                splitArray = current_line.split(",");
                if (splitArray[index_of_delivery_finish_time] == "") {
                    // or null?
                    StringBuilder sb = new StringBuilder();
                    int n = splitArray.length;
                    splitArray[2] = String.valueOf(rad.nextInt(100)+1);
                    splitArray[3] = String.valueOf(rad.nextInt(100)+1);
                    for (int i = 0; i < n-1; i++) {
                        sb.append(splitArray[i]);
                        sb.append(",");
                    }
                    sb.append(splitArray[n-1]);
                    writer.write(sb.toString());
                    writer.newLine();
                }
            }
            writer.close();
            reader2.close();
            reader1.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void select_test() {
        String input_name = "delivery.csv";
//        String output_name = "output.csv";
        String container_code = "";
        String current_line;
        String[] splitArray;
        int index_of_delivery_finish_time = 2;
        // the table has 500,000 records
        try {
            BufferedReader reader = new BufferedReader(new FileReader(input_name));
//            BufferedWriter writer = new BufferedWriter(new FileWriter(output_name));
            // pathname should be surrounded by
            current_line = reader.readLine();
            System.out.println(current_line);
//            writer.write(current_line);
//            writer.newLine();
            while ((current_line = reader.readLine()) != null) {
                splitArray = current_line.split(",");
                if (splitArray[index_of_delivery_finish_time].equals(container_code)) {
                    // use equal rather than ==
//                    writer.write(current_line);
//                    writer.newLine();
                    System.out.println(current_line);
                }
            }
            reader.close();
//            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void select_test_file() {
        String input_name = "delivery.csv";
        String output_name = "output.csv";
        String container_code = "";
        String current_line;
        String[] splitArray;
        int index_of_delivery_finish_time = 2;
        // the table has 500,000 records
        try {
            BufferedReader reader = new BufferedReader(new FileReader(input_name));
            BufferedWriter writer = new BufferedWriter(new FileWriter(output_name));
            // pathname should be surrounded by
            current_line = reader.readLine();
            writer.write(current_line);
            writer.newLine();
            while ((current_line = reader.readLine()) != null) {
                splitArray = current_line.split(",");
                if (splitArray[index_of_delivery_finish_time].equals(container_code)) {
                    // use equal rather than ==
                    writer.write(current_line);
                    writer.newLine();
                }
            }
            reader.close();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
