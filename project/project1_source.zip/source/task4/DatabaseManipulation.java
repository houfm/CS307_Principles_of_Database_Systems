
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Random;


public class DatabaseManipulation {
    private Connection con = null;
    private ResultSet resultSet;

    private String host = "localhost";
    private String dbname = "postgres";
    private String user = "test";
    private String pwd = "123456";
    private String port = "5432";


    private void getConnection() {
        try {
            Class.forName("org.postgresql.Driver");

        } catch (Exception e) {
            System.err.println("Cannot find the PostgreSQL driver. Check CLASSPATH.");
            System.exit(1);
        }

        try {
            String url = "jdbc:postgresql://" + host + ":" + port + "/" + dbname;
            con = DriverManager.getConnection(url, user, pwd);
            con.setAutoCommit(false);
        } catch (SQLException e) {
            System.err.println("Database connection failed");
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }


    private void closeConnection() {
        if (con != null) {
            try {
                con.close();
                con = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public void insert_test(String fileName){
        try (BufferedReader infile = new BufferedReader(new FileReader(fileName))) {
            long start;
            long end;
            long cnt = 0;
            String line;
            PreparedStatement statement = null;
            ArrayList<String[]> parts = new ArrayList<>();

            getConnection();
            try {
                statement= con.prepareStatement("insert into Delivery_Test(Item_id,Delivery_Item,Delivery_Finished_Time,Delivery_Courier,Delivery_City)"
                        + " values(?,?,?,?,?)");

            }catch (SQLException e){
                System.out.println(e.getMessage());
            }

            infile.readLine();
            while ((line = infile.readLine()) != null) {
                parts.add(line.split(","));
            }
            for (int i=0;i<parts.size();i++){
                statement.setInt(1,Integer.parseInt(parts.get(i)[0]));
                statement.setString(2,parts.get(i)[1]);
                statement.setString(3,parts.get(i)[2]);
                statement.setString(4,parts.get(i)[3]);
                statement.setString(5,parts.get(i)[4]);
                statement.executeUpdate();
                cnt++;
            }
            con.commit();
        }catch (SQLException e){
            System.err.println("SQL error: " + e.getMessage());
            try {
                con.rollback();
            } catch (Exception e2) {
            }
            closeConnection();
        }catch (IOException e) {
            System.err.println("Fatal error: " + e.getMessage());
            try {
                con.rollback();
            } catch (Exception e2) {
            }
            closeConnection();
    } finally {
            closeConnection();
        }
        }

    public void delete_test_certain(int id){
        getConnection();
        String sql="delete from delivery where Item_id="+id;
        try {
            PreparedStatement preparedStatement=con.prepareStatement(sql);
            preparedStatement.executeUpdate();
            System.out.println(preparedStatement.toString());
        }catch (SQLException e){
            e.printStackTrace();
        } finally {
            closeConnection();
        }
    }

    public void delete_test(){
        getConnection();
        Random random = new Random();
        int[] used = new int[500001];
        try {
            for (int i = 0; i < 10000; i++) {
                int index = random.nextInt(500000)+1;
                while (used[index] == 1){
                    index = random.nextInt(500000)+1;
                }
                used[index] =1;
                String sql="delete from delivery where Item_id="+index;
                PreparedStatement preparedStatement=con.prepareStatement(sql);
                preparedStatement.executeUpdate();
                System.out.println(preparedStatement.toString());
            }

        }catch (SQLException e){
            e.printStackTrace();
        }
        closeConnection();
    }

    public void select_test(){
        getConnection();
        StringBuilder stringBuilder = new StringBuilder();
        int id=1;
        try {
            Statement statement = con.createStatement();
            while (id<500001){
                resultSet = statement.executeQuery("select * from delivery_test where Item_id="+id);
                while (resultSet.next()) {
                    String str = resultSet.getString(3);
                    if(str==null){
                        for (int i=1;i<5;i++){
                            stringBuilder.append(resultSet.getString(i)).append(",");
                        }
                    }
                    stringBuilder.append(resultSet.getString(5));
            }
                id++;
            }
        }catch (SQLException e){
            e.printStackTrace();
        } finally {
            closeConnection();
        }

    }

    public void update_test(){
        getConnection();
        Random random = new Random();
        int r = random.nextInt(100);
        int R = random.nextInt(100);
        int id =1;
            try {
                Statement statement = con.createStatement();
                while (id<500001){
                    resultSet = statement.executeQuery("select * from delivery_test where Item_id="+id);
                    while (resultSet.next()) {
                        String str = resultSet.getString(3);
                        if(str==null){
                            PreparedStatement preparedStatement =con.prepareStatement("update delivery_test set delivery_finished_time = ?,delivery_courier = ?  where item_id = " + id);
                            preparedStatement.setString(1,String.valueOf(r));
                            preparedStatement.setString(2,String.valueOf(R));
                            preparedStatement.executeUpdate();
                        id++;
                        }
                    }
                }
                con.commit();
//                String check = "select * from delivery_test where item_id= " + id;
//                PreparedStatement preparedStatement0 = con.prepareStatement(check);
//                resultSet = preparedStatement0.executeQuery();
//                while (resultSet.next()) {
//                    String str = resultSet.getString(3);
//                    if (str == null) {
//                        Random random = new Random();
//                        int r = random.nextInt(100);
//                        int R = random.nextInt(100);
//                        PreparedStatement preparedStatement = con.prepareStatement("update delivery_set set delivery_finished_time = ?,delivery_courier =?, where item_id = " + id);
//                        preparedStatement.setString(1, String.valueOf(r));
//                        preparedStatement.setString(2, String.valueOf(R));
//                        preparedStatement.executeUpdate();
//                        id++;
//                    }
//                }
            }catch (SQLException e) {
                e.printStackTrace();
            }finally {
                closeConnection();
            }
    }

    public static void create_file() {
        String input_name = "delivery.csv";
        String output_name = "output.csv";
        int test_number = 10000;
        String[] lines = new String[501000];
        int[] used = new int[501000];
        String current_line;
        Random random = new Random();
        int index;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(input_name));
            int i=0;
            while ((current_line = reader.readLine()) != null){
                lines[i] = current_line;
                i++;
            }
            BufferedWriter writer = new BufferedWriter(new FileWriter(output_name));
            writer.write(lines[0]);
            writer.newLine();
            for (int j = 0; j < test_number; j++) {
                index = random.nextInt(500000)+1;
                while (used[index] == 1){
                    index = random.nextInt(500000)+1;
                }
                writer.write(lines[index]);
                used[index] =1;
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
