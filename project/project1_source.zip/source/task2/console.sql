create table if not exists Item
(
    Item_Name    varchar(30) primary key,
    Item_Price   int         not null,
    Item_Class   varchar(30) not null,
    Item_LogTime timestamp   not null
);

create table if not exists Retrieval_Courier
(

    Courier_Name         varchar(30) primary key,
    Courier_Birth_Year   int                not null,
    Courier_Gender       varchar(30)        not null,
    Courier_Phone_Number varchar(30) unique not null,
    Courier_City         varchar(30)        not null,
    Company_Name         varchar(30)
    -- as one courier may send more than one items, there should be unique
    -- unique constraint allows storing ONE NULL value in the column.

);

create table if not exists Retrieval
(
    Retrieval_Item       varchar(30) primary key
        constraint Item_Name_fk references Item (Item_Name),
    -- ????????????????
    Retrieval_Start_Time date        not null,
    Retrieval_Courier    varchar(30)
        constraint Retrieval_Courier_fk references Retrieval_Courier (Courier_Name),
    Retrieval_City       varchar(30) not null
);

create table if not exists Delivery_Courier
(
    Courier_Name         varchar(30) primary key,
    Courier_Birth_Year   int                not null,
    Courier_Gender       varchar(30)        not null,
    Courier_Phone_Number varchar(30) unique not null,
    Courier_City         varchar(30)        not null,
    Company_Name         varchar(30)
);

create table if not exists Delivery
(
    Item_id                int,
    Delivery_Item          varchar(30) primary key
        constraint Item_Name_fk references Item (Item_Name),
    Delivery_Finished_Time date,
    -- Can be EMPTY if the delivery is not finished.
    Delivery_Courier       varchar(30)
        constraint Delivery_Courier_fk references Delivery_Courier (Courier_Name),
    Delivery_City          varchar(30) not null
);



create table if not exists Export
(
    Export_Item varchar(30) primary key
        constraint Item_Name_fk references Item (Item_Name),
    Export_Tax  double precision not null,
    Export_Time date,
    Export_City varchar(30)      not null

);

create table if not exists Import
(
    Import_Item varchar(30) primary key
        constraint Item_Name_fk references Item (Item_Name),
    Import_Tax  double precision not null,
    Import_Time date,
    Import_City varchar(30)      not null
);


create table if not exists Ship
(
    Ship_Name    varchar(30) primary key,
    Company_Name varchar(30)

);


create table if not exists Containing
(
    Containing_Item varchar(30)
        constraint Containing_Item_fk references Item (Item_Name) primary key,
    Container_Code  varchar(30),
    Container_Type  varchar(30),
    Ship_Name       varchar(30)
        constraint Ship_fk references Ship (Ship_Name)
);


create table if not exists Delivery_Test
(
    Item_id                int,
    Delivery_Item          varchar(30) primary key,
    Delivery_Finished_Time varchar(30),
    -- Can be EMPTY if the delivery is not finished.
    Delivery_Courier       varchar(30),
    Delivery_City          varchar(30) not null
);



-- select T2.name, T2.Courier_City, T2.Company_Name
-- from (select A.Courier_Name name, count(*) count, Courier_City, Company_Name
--       from Retrieval_Courier A
--                join Retrieval B on A.Courier_Name = B.Retrieval_Courier
--       group by Courier_City, Company_Name, A.Courier_Name) T2
--          join (select max(count) max, Courier_City, Company_Name
--                from (select count(*) count, Courier_City, Company_Name
--                      from Retrieval_Courier A
--                               join Retrieval B on A.Courier_Name = B.Retrieval_Courier
--                      group by Courier_City, Company_Name, A.Courier_Name) T1
--                group by Company_Name, Courier_City) T3
--               on (T2.Company_Name = T3.Company_Name and T2.Courier_City = T3.Courier_City)
-- where T2.count = T3.max;
--
-- select T2.name, T2.Courier_City, T2.Company_Name
-- from (select A.Courier_Name name, count(*) count, Courier_City, Company_Name
--       from Delivery_Courier A
--                join Delivery B on A.Courier_Name = B.Delivery_Courier
--       group by Courier_City, Company_Name, A.Courier_Name) T2
--          join (select max(count) max, Courier_City, Company_Name
--                from (select count(*) count, Courier_City, Company_Name
--                      from Delivery_Courier A
--                               join Delivery B on A.Courier_Name = B.Delivery_Courier
--                      group by Courier_City, Company_Name, A.Courier_Name) T1
--                group by Company_Name, Courier_City) T3
--               on (T2.Company_Name = T3.Company_Name and T2.Courier_City = T3.Courier_City)
-- where T2.count = T3.max;
--
-- select Export_City, sum(taxRate * B.sum) summary
-- from (select distinct Item_Class, Export_City, taxRate
--       from (select Item_Class,
--                    Item_Price,
--                    Export_Tax,
--                    Export_City,
--                    round(cast(Export_Tax / Item_Price as numeric), 8) taxRate
--             from (select Item_Class, Item_Name, Item_Price, Export_City, Export_Tax, Retrieval_Courier
--                   from (select Item_Class, Item_Name, Item_Price, E.Export_Tax, E.Export_City
--                         from item
--                                  join Export E on Item.Item_Name = E.Export_Item) T1
--                            join Retrieval on Item_Name = Retrieval.Retrieval_Item) T2
--                      join Retrieval_Courier on T2.Retrieval_Courier = Retrieval_Courier.Courier_Name
--             where Company_Name = 'Amazon.com') T) A
--          join (select Item_Class, sum(Item_Price) sum
--                from (select Item_Name, Item_Class, Item_Price, Retrieval_Courier
--                      from item
--                               join Retrieval R on Item.Item_Name = R.Retrieval_Item) T
--                         join Retrieval_Courier on T.Retrieval_Courier = Retrieval_Courier.Courier_Name
--                where Company_Name = 'Amazon.com'
--                group by Item_Class) B on A.Item_Class = B.Item_Class
-- group by Export_City
-- order by summary
-- limit 1;





