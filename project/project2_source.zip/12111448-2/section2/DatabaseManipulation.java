package main;

import main.interfaces.*;

import java.sql.*;
import java.util.ArrayList;

public class DatabaseManipulation implements IDatabaseManipulation {
    private Connection con = null;
    private static String url;
    private static String user;
    private static String password;
    private static PreparedStatement preparedStatement = null;

    public DatabaseManipulation(String database, String root, String pass) {
        url = "jdbc:postgresql://" + database;
        user = root;
        password = pass;

        getConnection(root, pass);

        String sql = "create table if not exists Item" +
                "(" +
                "    Item_Name    varchar(30) primary key," +
                "    Item_Price   double precision         not null," +
                "    Item_Class   varchar(30) not null," +
                "    Item_State   varchar(30) not null," +
                "    Item_Company varchar(30) not null" +
                ");" +
                "" +
                "create table if not exists Courier" +
                "(" +
                "    Courier_Name         varchar(30) primary key," +
                "    Courier_Type         varchar(30)        not null," +
                "    Courier_Age          int                not null," +
                "    Courier_Gender       varchar(30)        not null," +
                "    Courier_Phone_Number varchar(30) unique not null," +
                "    Courier_City         varchar(30)        not null," +
                "    Courier_Company      varchar(30)        not null," +
                "    Courier_Password     varchar(30) unique not null" +
                ");" +
                "" +
                "create table if not exists Retrieval" +
                "(" +
                "    Retrieval_Item    varchar(30) primary key" +
                "        constraint Item_Name_fk references Item (Item_Name)," +
                "    Retrieval_Courier varchar(30)," +
//                "        constraint Retrieval_Courier_fk references Courier (Courier_Name)," +
                "    Retrieval_City    varchar(30) not null" +
                ");" +
                "" +
                "create table if not exists Delivery" +
                "(" +
                "    Delivery_Item    varchar(30) primary key" +
                "        constraint Item_Name_fk references Item (Item_Name)," +
                "    Delivery_Courier varchar(30)," +
//                "        constraint Delivery_Courier_fk references Courier (Courier_Name)," +
                "    Delivery_City    varchar(30) not null" +
                ");" +
                "" +
                "create table if not exists Seaport_Officer" +
                "(" +
                "    Officer_Name         varchar(30) primary key," +
                "    Officer_Type         varchar(30)        not null," +
                "    Officer_Age          int                not null," +
                "    Officer_Gender       varchar(30)        not null," +
                "    Officer_Phone_Number varchar(30) unique not null," +
                "    Officer_City         varchar(30)        not null," +
                "    Officer_Password     varchar(30) unique not null" +
                ");" +
                "" +
                "create table if not exists Export" +
                "(" +
                "    Export_Item    varchar(30) primary key" +
                "        constraint Item_Name_fk references Item (Item_Name)," +
                "    Export_Tax     double precision not null," +
                "    Export_City    varchar(30)      not null," +
                "    Export_Officer varchar(30)" +
//                "        constraint Export_Officer_fk references Seaport_Officer (Officer_Name)" +
                ");" +
                "" +
                "" +
                "" +
                "create table if not exists Import" +
                "(" +
                "    Import_Item    varchar(30) primary key" +
                "        constraint Item_Name_fk references Item (Item_Name)," +
                "    Import_Tax     double precision not null," +
                "    Import_City    varchar(30)      not null," +
                "    Import_Officer varchar(30)" +
//                "        constraint Import_Officer_fk references Seaport_Officer (Officer_Name)" +
                ");" +
                "" +
                "create table if not exists Company_Manager" +
                "(" +
                "    Manager_Name         varchar(30) primary key," +
                "    Manager_Type         varchar(30)        not null," +
                "    Manager_Age          int                not null," +
                "    Manager_Gender       varchar(30)        not null," +
                "    Manager_Phone_Number varchar(30) unique not null," +
                "    Manager_Company      varchar(30)        not null," +
                "    Manager_Password     varchar(30) unique not null" +
                ");" +
                "" +
                "create table if not exists Shipping" +
                "(" +
                "    Shipping_Item varchar(30)" +
                "        constraint Shipping_Item_fk references Item (Item_Name) primary key," +
                "    Ship_Name     varchar(30)," +
                "    Company_Name  varchar(30)" +
                ");" +
                "" +
                "create table if not exists Containing" +
                "(" +
                "    Containing_Item varchar(30)" +
                "        constraint Containing_Item_fk references Item (Item_Name) primary key," +
                "    Container_Code  varchar(30)," +
                "    Container_Type  varchar(30)," +
                "    Ship            varchar(30)" +
                ");" +
                "" +
                "create table if not exists SUSTC_Department_Manager" +
                "(" +
                "    Manager_Name         varchar(30) primary key," +
                "    Manager_Type         varchar(30)        not null," +
                "    Manager_Age          int                not null," +
                "    Manager_Gender       varchar(30)        not null," +
                "    Manager_Phone_Number varchar(30) unique not null," +
                "    Manager_Password     varchar(30) unique not null" +
                ");" ;

                String user=
                "drop user if exists Courier;" +
                "drop user if exists SeaportOfficer;" +
                "drop user if exists Company_Manager;" +
                "drop user if exists SUSTC_Department_Manager;" +
                "" +
                "create user Courier with password '1';" +
                "create user SeaportOfficer with password '2';" +
                "create user Company_Manager with password '3';" +
                "create user SUSTC_Department_Manager with password '4';" +
                "" +
                "grant select, update on Item,Export,Import to seaportofficer;" +
                "grant select on Item,Import,Export,containing,shipping to company_manager;" +
                "grant update on containing,Item to company_manager;" +
                "grant select on Item,Retrieval,Delivery to courier;" +
                "grant insert on Item,Retrieval,Delivery,Export,Import,Containing,Shipping to courier;" +
                "grant update on Item,Delivery,Retrieval to courier;" +
                "grant select on Item,Delivery,Retrieval,Export,Import,Containing,Shipping,Company_Manager,Courier,Seaport_Officer,SUSTC_Department_Manager to sustc_department_manager;";
//        create table and user and set permissions

        String userExisting = "select * from pg_user where usename = 'courier';";
        String userRevoking = "revoke all on Item,Export,Import from seaportofficer;\n" +
                "revoke all on Item,Import,Export,containing,shipping from company_manager;\n" +
                "revoke all on Item,Retrieval,Delivery,Export,Import,Containing,Shipping from courier;\n" +
                "revoke all on Item,Delivery,Retrieval,Export,Import,Containing,Shipping,Company_Manager,Courier," +
                "Seaport_Officer,SUSTC_Department_Manager from sustc_department_manager;";
        try {
            Statement statement = con.createStatement();
            statement.executeUpdate(sql);
            con.commit();
            if (statement.executeQuery(userExisting).next()) {
                statement.executeUpdate(userRevoking);
                con.commit();
            }
//            statement.close();
            statement.executeUpdate(user);
            con.commit();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }

    }

    @Override
    public void $import(String recordsCSV, String staffsCSV) {
        String[] records;
        String[] staffs;
        PreparedStatement stmt = null;

        records = recordsCSV.split("[,\\n]");
        staffs = staffsCSV.split("[,\\n]");

        String Item = "insert into Item(Item_Name, Item_Price, Item_Class, Item_State, Item_Company) values (?,?,?,?,?)";
        String Courier = "insert into Courier(Courier_Name, Courier_Type, Courier_Age, Courier_Gender, Courier_Phone_Number, Courier_City, Courier_Company, Courier_Password) values (?,?,?,?,?,?,?,?)";
        String Retrieval = "insert into Retrieval(Retrieval_Item, Retrieval_Courier, Retrieval_City) values (?,?,?)";
        String Delivery = "insert into Delivery(Delivery_Item, Delivery_Courier, Delivery_City) values (?,?,?)";
        String Seaport_Officer = "insert into Seaport_Officer(Officer_Name, Officer_Type, Officer_Age, Officer_Gender, Officer_Phone_Number, Officer_City, Officer_Password) values (?,?,?,?,?,?,?)";
        String Export = "insert into Export(Export_Item, Export_Tax, Export_City, Export_Officer) values (?,?,?,?)";
        String Import = "insert into Import(Import_Item, Import_Tax, Import_City, Import_Officer) values (?,?,?,?)";
        String Company_Manager = "insert into Company_Manager(Manager_Name, Manager_Type, Manager_Age, Manager_Gender, Manager_Phone_Number, Manager_Company, Manager_Password) values (?,?,?,?,?,?,?)";
        String Shipping = "insert into Shipping(Shipping_Item, Ship_Name, Company_Name) values (?,?,?)";
        String Containing = "insert into Containing(Containing_Item, Container_Code, Container_Type,Ship) values (?,?,?,?)";
        String SUSTC_Department_Manager = "insert into SUSTC_Department_Manager(Manager_Name, Manager_Type, Manager_Age, Manager_Gender, Manager_Phone_Number, Manager_Password) values (?,?,?,?,?,?)";

        getConnection(user, password);

        try {
            stmt = con.prepareStatement(Item);
            for (int i = 1; i < records.length / 18; i++) {
                stmt.setString(1, records[i * 18]);
                stmt.setDouble(2, Double.parseDouble(records[i * 18 + 2]));
                stmt.setString(3, records[i * 18 + 1]);
                stmt.setString(4, records[i * 18 + 17]);
                stmt.setString(5, records[i * 18 + 16]);
                stmt.executeUpdate();
            }

            stmt = con.prepareStatement(Courier);
            for (int i = 1; i < staffs.length / 8; i++) {
                if (staffs[i * 8 + 1].equals("Courier")) {
                    stmt.setString(1, staffs[i * 8]);
                    stmt.setString(2, staffs[i * 8 + 1]);
                    stmt.setInt(3, Integer.parseInt(staffs[i * 8 + 5]));
                    stmt.setString(4, staffs[i * 8 + 4]);
                    stmt.setString(5, staffs[i * 8 + 6]);
                    stmt.setString(6, staffs[i * 8 + 3]);
                    stmt.setString(7, staffs[i * 8 + 2]);
                    stmt.setString(8, staffs[i * 8 + 7]);
                    stmt.executeUpdate();
                }
            }

            stmt = con.prepareStatement(Retrieval);
            for (int i = 1; i < records.length / 18; i++) {
                if (records[i * 18 + 4].equals("")) {
                    stmt.setString(1, records[i * 18]);
                    stmt.setString(2, null);
                    stmt.setString(3, records[i * 18 + 3]);
                } else {
                    stmt.setString(1, records[i * 18]);
                    stmt.setString(2, records[i * 18 + 4]);
                    stmt.setString(3, records[i * 18 + 3]);
                }
                stmt.executeUpdate();
            }

            stmt = con.prepareStatement(Delivery);
            for (int i = 1; i < records.length / 18; i++) {
                if (records[i * 18 + 6].equals("")) {
                    stmt.setString(1, records[i * 18]);
                    stmt.setString(2, null);
                    stmt.setString(3, records[i * 18 + 5]);
                } else {
                    stmt.setString(1, records[i * 18]);
                    stmt.setString(2, records[i * 18 + 6]);
                    stmt.setString(3, records[i * 18 + 5]);
                }
                stmt.executeUpdate();
            }

            stmt = con.prepareStatement(Seaport_Officer);
            for (int i = 1; i < staffs.length / 8; i++) {
                if (staffs[i * 8 + 1].equals("Seaport Officer")) {
                    stmt.setString(1, staffs[i * 8]);
                    stmt.setString(2, staffs[i * 8 + 1]);
                    stmt.setInt(3, Integer.parseInt(staffs[i * 8 + 5]));
                    stmt.setString(4, staffs[i * 8 + 4]);
                    stmt.setString(5, staffs[i * 8 + 6]);
                    stmt.setString(6, staffs[i * 8 + 3]);
                    stmt.setString(7, staffs[i * 8 + 7]);
                    stmt.executeUpdate();
                }
            }

            stmt = con.prepareStatement(Export);
            for (int i = 1; i < records.length / 18; i++) {
                if (records[i * 18 + 11].equals("")) {
                    stmt.setString(1, records[i * 18]);
                    stmt.setDouble(2, Double.parseDouble(records[i * 18 + 9]));
                    stmt.setString(3, records[i * 18 + 7]);
                    stmt.setString(4, null);
                } else {
                    stmt.setString(1, records[i * 18]);
                    stmt.setDouble(2, Double.parseDouble(records[i * 18 + 9]));
                    stmt.setString(3, records[i * 18 + 7]);
                    stmt.setString(4, records[i * 18 + 11]);
                }
                stmt.executeUpdate();
            }

            stmt = con.prepareStatement(Import);
            for (int i = 1; i < records.length / 18; i++) {
                if (records[i * 18 + 12].equals("")) {
                    stmt.setString(1, records[i * 18]);
                    stmt.setDouble(2, Double.parseDouble(records[i * 18 + 10]));
                    stmt.setString(3, records[i * 18 + 8]);
                    stmt.setString(4, null);
                } else {
                    stmt.setString(1, records[i * 18]);
                    stmt.setDouble(2, Double.parseDouble(records[i * 18 + 10]));
                    stmt.setString(3, records[i * 18 + 8]);
                    stmt.setString(4, records[i * 18 + 12]);
                }
                stmt.executeUpdate();
            }

            stmt = con.prepareStatement(Company_Manager);
            for (int i = 1; i < staffs.length / 8; i++) {
                if (staffs[i * 8 + 1].equals("Company Manager")) {
                    stmt.setString(1, staffs[i * 8]);
                    stmt.setString(2, staffs[i * 8 + 1]);
                    stmt.setInt(3, Integer.parseInt(staffs[i * 8 + 5]));
                    stmt.setString(4, staffs[i * 8 + 4]);
                    stmt.setString(5, staffs[i * 8 + 6]);
                    stmt.setString(6, staffs[i * 8 + 2]);
                    stmt.setString(7, staffs[i * 8 + 7]);
                    stmt.executeUpdate();
                }
            }

            stmt = con.prepareStatement(Shipping);
            for (int i = 1; i < records.length / 18; i++) {
                if (records[i * 18 + 15].equals("")) {
                    stmt.setString(1, records[i * 18]);
                    stmt.setString(2, null);
                    stmt.setString(3, records[i * 18 + 16]);
                } else {
                    stmt.setString(1, records[i * 18]);
                    stmt.setString(2, records[i * 18 + 15]);
                    stmt.setString(3, records[i * 18 + 16]);
                }
                stmt.executeUpdate();
            }

            stmt = con.prepareStatement(Containing);
            for (int i = 1; i < records.length / 18; i++) {
                if (records[i * 18 + 13].equals("")) {
                    stmt.setString(1, records[i * 18]);
                    stmt.setString(2, null);
                    stmt.setString(3, null);
                    stmt.setString(4, null);
                } else if (records[i * 18 + 15].equals("")) {
                    stmt.setString(1, records[i * 18]);
                    stmt.setString(2, records[i * 18 + 13]);
                    stmt.setString(3, records[i * 18 + 14]);
                    stmt.setString(4, null);
                } else {
                    stmt.setString(1, records[i * 18]);
                    stmt.setString(2, records[i * 18 + 13]);
                    stmt.setString(3, records[i * 18 + 14]);
                    stmt.setString(4, records[i * 18 + 15]);
                }
                stmt.executeUpdate();
            }

            stmt = con.prepareStatement(SUSTC_Department_Manager);
            for (int i = 1; i < staffs.length / 8; i++) {
                if (staffs[i * 8 + 1].equals("SUSTC Department Manager")) {
                    stmt.setString(1, staffs[i * 8]);
                    stmt.setString(2, staffs[i * 8 + 1]);
                    stmt.setInt(3, Integer.parseInt(staffs[i * 8 + 5]));
                    stmt.setString(4, staffs[i * 8 + 4]);
                    stmt.setString(5, staffs[i * 8 + 6]);
                    stmt.setString(6, staffs[i * 8 + 7]);
                    stmt.executeUpdate();
                }
            }

            con.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        closeConnection();

    }

    @Override
    public double getImportTaxRate(LogInfo log, String city, String itemClass) {
        ResultSet resultSet;

        try {
            if (!check_CompanyManager(log)) {
                return -1;
            } else {
                getConnection("company_manager", "3");
                Statement statement = con.createStatement();
                boolean $class = statement.executeQuery("select * from Item where Item_Class = '" + itemClass + "' ").next();
                boolean $city = statement.executeQuery("select * from Import where Import_City = '" + city + "'").next();
                if ($class && $city) {
                    resultSet = statement.executeQuery("select Import_Tax / Item_Price\n" +
                            "from Item\n" +
                            "         join Import I on Item.Item_Name = I.Import_Item\n" +
                            "where Item_Class = '" + itemClass + "'\n" +
                            "  and Import_City = '" + city + "'");
                    resultSet.next();
                    return Double.parseDouble(resultSet.getString(1));
                } else return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } finally {
            closeConnection();
        }
    }

    @Override
    public double getExportTaxRate(LogInfo log, String city, String itemClass) {
        ResultSet resultSet;

        try {
            if (!check_CompanyManager(log)) {
                return -1;
            } else {
                getConnection("company_manager", "3");
                Statement statement = con.createStatement();
                boolean $class = statement.executeQuery("select * from Item where Item_Class = '" + itemClass + "' ").next();
                boolean $city = statement.executeQuery("select * from Export where Export_City = '" + city + "'").next();
                if ($class && $city) {
                    resultSet = statement.executeQuery("select Export_Tax / Item_Price\n" +
                            "from Item\n" +
                            "         join Export E on Item.Item_Name = E.Export_Item\n" +
                            "where Item_Class = '" + itemClass + "'\n" +
                            "  and Export_City = '" + city + "'");
                    resultSet.next();
                    return Double.parseDouble(resultSet.getString(1));
                } else return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } finally {
            closeConnection();
        }
    }

    @Override
    public boolean loadItemToContainer(LogInfo log, String itemName, String containerCode) {
        ResultSet resultSet;

        try {
            if (!check_CompanyManager(log)) {
                return false;
            } else {
                getConnection("company_manager", "3");
                Statement statement = con.createStatement();
                boolean load = statement.executeQuery("select *\n" +
                        "from Containing\n" +
                        "         join Item I on I.Item_Name = Containing_Item\n" +
                        "where Item_State = 'Packing to Container'\n" +
                        "  and Container_Code is null\n" +
                        "  and Item_Name = '" + itemName + "'").next();
//                boolean containerEverNotUsed = statement.executeQuery("select * from Containing where Container_Code ='" + containerCode + "'").next();
                boolean containerUsing = statement.executeQuery("select *\n" +
                        "from Containing\n" +
                        "         join Item I on I.Item_Name = Containing_Item\n" +
                        "where (Item_State = 'Waiting for Shipping' or Item_State = 'Shipping' or Item_State = 'Unpacking from Container')\n" +
                        "  and Container_Code = '" + containerCode + "'").next();
                resultSet = statement.executeQuery("select Container_Type\n" +
                        "from containing\n" +
                        "where Container_Code = '" + containerCode + "'");
                resultSet.next();
                String type = resultSet.getString(1);
                if (load && (!containerUsing)) {
                    statement.executeUpdate("update containing set Container_Code = '" + containerCode + "' where Containing_Item ='" + itemName + "'");
                    statement.executeUpdate("update containing set Container_Type = '" + type + "' where Containing_Item ='" + itemName + "'");
                    statement.executeUpdate("update Item set Item_State = 'Waiting for Shipping' where Item_Name = '" + itemName + "'");
                    con.commit();
                    return true;
                } else return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    @Override
    public boolean loadContainerToShip(LogInfo log, String shipName, String containerCode) {
        ResultSet resultSet;

        try {
            if (!check_CompanyManager(log)) {
                return false;
            } else {
                getConnection("company_manager", "3");
                Statement statement = con.createStatement();
                boolean container = statement.executeQuery("select *\n" +
                        "from Containing\n" +
                        "         join Item I on I.Item_Name = Containing_Item\n" +
                        "where (Item_State = 'Waiting for Shipping')\n" +
                        "  and Container_Code = '" + containerCode + "'\n" +
                        "  and Ship is null").next();
                boolean ship = statement.executeQuery("select *\n" +
                        "from Containing\n" +
                        "         join Item I on I.Item_Name = Containing_Item\n" +
                        "where (Item_State = 'Shipping')\n" +
                        "  and Ship = '" + shipName + "'").next();
                if (container && !ship) {
                    statement.executeUpdate("update Containing set Ship = '" + shipName + "' where Container_Code = '" + containerCode + "' and Ship is null");
                    con.commit();
                    return true;
                } else return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    @Override
    public boolean shipStartSailing(LogInfo log, String shipName) {
        ResultSet resultSet;

        try {
            if (!check_CompanyManager(log)) {
                return false;
            } else {
                getConnection("company_manager", "3");
                Statement statement = con.createStatement();
                boolean ship = statement.executeQuery("select *\n" +
                        "from Containing\n" +
                        "         join Item I on I.Item_Name = Containing_Item\n" +
                        "where (Ship = '" + shipName + "')\n" +
                        "  and Item_State = 'Shipping'").next();
                if (!ship) {
                    resultSet = statement.executeQuery("select Item_Name\n" +
                            "from Containing\n" +
                            "         join Item I on I.Item_Name = Containing_Item\n" +
                            "where (Ship = '" + shipName + "')\n" +
                            "  and Item_State = 'Waiting for Shipping'");
                    ArrayList<String> item = new ArrayList<>();
                    while (resultSet.next()) {
                        item.add(resultSet.getString(1));
                    }
                    if (item.size() != 0) {
                        for (int i = 0; i < item.size(); i++) {
                            statement.executeUpdate("update Item\n" +
                                    "set Item_State = 'Shipping'\n" +
                                    "where Item_Name = '" + item.get(i) + "'");
                        }
                        con.commit();
                        return true;
                    } else return false;
                } else return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    @Override
    public boolean unloadItem(LogInfo log, String itemName) {
        ResultSet resultSet;

        try {
            if (!check_CompanyManager(log)) {
                return false;
            } else {
                getConnection("company_manager", "3");
                Statement statement = con.createStatement();
                boolean shipping = statement.executeQuery("select * from Item where Item_Name = '" + itemName + "' and Item_State = 'Shipping'").next();
                if (shipping) {
                    statement.executeUpdate("update Item\n" +
                            "set Item_State = 'Unpacking from Container'\n" +
                            "where Item_Name = '" + itemName + "'");
                    con.commit();
                    return true;
                } else return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    @Override
    public boolean itemWaitForChecking(LogInfo log, String item) {
        ResultSet resultSet;

        try {
            if (!check_CompanyManager(log)) {
                return false;
            } else {
                getConnection("company_manager", "3");
                Statement statement = con.createStatement();
                boolean waiting = statement.executeQuery("select * from Item where Item_Name = '" + item + "' and Item_State = 'Unpacking from Container'").next();
                if (waiting) {
                    statement.executeUpdate("update Item\n" +
                            "set Item_State = 'Import Checking'\n" +
                            "where Item_Name = '" + item + "'");
                    con.commit();
                    return true;
                } else return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    @Override
    public boolean newItem(LogInfo log, ItemInfo item) {
        try {
            if (!check_Courier(log)) {
                return false;
            } else if (((item.state() != null) && (!item.state().equals(ItemState.PickingUp)))
                    || (item.delivery().courier() != null)
                    || (item.export().officer() != null)
                    || (item.$import().officer() != null)
                    || item.retrieval().city().equals(item.export().city())
                    || item.retrieval().city().equals(item.$import().city())
                    || item.retrieval().city().equals(item.delivery().city())
                    || item.export().city().equals(item.$import().city())
                    || item.export().city().equals(item.delivery().city())
                    || item.delivery().city().equals(item.$import().city())
                    || item.name() == null
            ) {
                return false;
            } else {
                double standard_export_tax_rate = getExportTaxRate(
                        new LogInfo("Yu Bao", LogInfo.StaffType.CompanyManager, "2113353997898296736"),
                        item.export().city(), item.$class());
                double standard_import_tax_rate = getImportTaxRate(
                        new LogInfo("Yu Bao", LogInfo.StaffType.CompanyManager, "2113353997898296736"),
                        item.$import().city(), item.$class());
                getConnection(user, password);
                Statement statement0 = con.createStatement();
                boolean existClass = statement0.executeQuery("select from Item where Item_Class = '" + item.$class() + "'").next();
                boolean checkPrice = item.price() <= 0;
                if (!existClass || checkPrice) {
                    return false;
                }
                ResultSet exist0 = statement0.executeQuery("select * from Item where Item_Name = '" + item.name() + "'");
                boolean exist = exist0.next();
                ResultSet export_tax_rate_resultset = statement0.executeQuery("select Export_Tax / Item_Price\n" +
                        "from Item\n" +
                        "         join Export E on Item.Item_Name = E.Export_Item\n" +
                        "where Item_Class = '" + item.$class() + "'\n" +
                        "  and Export_City = '" + item.export().city() + "'");
                export_tax_rate_resultset.next();
                double real_export_tax_rate = export_tax_rate_resultset.getDouble(1);
                ResultSet import_tax_rate_resultset = statement0.executeQuery("select Import_Tax / Item_Price\n" +
                        "from Item\n" +
                        "         join Import I on Item.Item_Name = I.Import_Item\n" +
                        "where Item_Class = '" + item.$class() + "'\n" +
                        "  and Import_City = '" + item.$import().city() + "'");
                import_tax_rate_resultset.next();
                double real_import_tax_rate = import_tax_rate_resultset.getDouble(1);
                ResultSet get_company_result = statement0.executeQuery("select courier_company from courier " +
                        "where courier_name='" + log.name() + "'");
                get_company_result.next();
                String company = get_company_result.getString(1);
                closeConnection();

                getConnection("courier", "1");
                Statement statement = con.createStatement();
                if (real_import_tax_rate != standard_import_tax_rate ||
                        real_export_tax_rate != standard_export_tax_rate ||
                        exist) {
                    return false;
                } else {
                    statement.executeUpdate
                            ("insert into Item(Item_Name, Item_Price, Item_Class, Item_State, Item_Company) " +
                                    "values ('" + item.name() + "','" + item.price() + "','" + item.$class() + "','Picking-up','" + company + "')");
                    statement.executeUpdate("insert into Retrieval (Retrieval_Item, Retrieval_Courier, Retrieval_City) " +
                            "values ('" + item.name() + "','" + log.name() + "','" + item.retrieval().city() + "')");
                    statement.executeUpdate("insert into Delivery (Delivery_Item, Delivery_Courier, Delivery_City) " +
                            "VALUES ('" + item.name() + "','" + item.delivery().courier() + "','" + item.delivery().city() + "')");
                    statement.executeUpdate("insert into Export (Export_Item, Export_Tax, Export_City, Export_Officer) " +
                            "VALUES ('" + item.name() + "','" + real_export_tax_rate + "','" + item.export().city() + "','" + item.export().officer() + "')");
                    statement.executeUpdate("insert into Import (Import_Item, Import_Tax, Import_City, Import_Officer) " +
                            "VALUES ('" + item.name() + "','" + real_import_tax_rate + "','" + item.$import().city() + "','" + item.$import().officer() + "')");
                    statement.executeUpdate("insert into containing (Containing_Item) values ('" + item.name() + "')");
                    statement.executeUpdate("insert into shipping (Shipping_Item) values ('" + item.name() + "')");
                    con.commit();

                    return true;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    @Override
    public boolean setItemState(LogInfo log, String name, ItemState s) {

        try {
            if (!check_Courier(log)) {
                return false;
            } else {
                getConnection(user, password);
                Statement statement0 = con.createStatement();
                ResultSet rs = statement0.executeQuery("select Courier_City from Courier where Courier_Name = '" + log.name() + "'");
                rs.next();
                String city = rs.getString(1);
                closeConnection();

                getConnection("courier", "1");
                Statement statement = con.createStatement();
                boolean exist = statement.executeQuery("select Item_State\n" +
                        "from item\n" +
                        "         join Retrieval R on Item.Item_Name = R.Retrieval_Item\n" +
                        "where Retrieval_Courier = '" + log.name() + "'\n" +
                        "  and Item_Name = '" + name + "'").next();
                if (!exist) {
                    return false;
                } else {
                    ResultSet state1 = statement.executeQuery("select Item_State\n" +
                            "from item\n" +
                            "         join Retrieval R on Item.Item_Name = R.Retrieval_Item\n" +
                            "where Retrieval_Courier = '" + log.name() + "'\n" +
                            "  and Item_Name = '" + name + "'");
                    state1.next();
                    String s1 = state1.getString(1);
                    if (state1.getString(1).equals("null")) {
                        if (s.equals(ItemState.PickingUp)) {
                            statement.executeUpdate("update Item\n" +
                                    "set Item_State = 'Picking-up'\n" +
                                    "where Item_Name = '" + name + "'");
                            con.commit();
                            return true;
                        } else return false;
                    } else if (state1.getString(1).equals("Picking-up")) {
                        if (s.equals(ItemState.ToExportTransporting)) {
                            statement.executeUpdate("update Item\n" +
                                    "set Item_State = 'To-Export Transporting'\n" +
                                    "where Item_Name = '" + name + "'");
                            con.commit();
                            return true;
                        } else return false;
                    } else if (state1.getString(1).equals("To-Export Transporting")) {
                        if (s.equals(ItemState.ExportChecking)) {
                            statement.executeUpdate("update Item\n" +
                                    "set Item_State = 'Export Checking'\n" +
                                    "where Item_Name = '" + name + "'");
                            con.commit();
                            return true;
                        } else return false;
                    } else {
                        boolean exist1 = statement.executeQuery("select Delivery_City\n" +
                                "from item\n" +
                                "         join Delivery D on Item.Item_Name = D.Delivery_Item\n" +
                                "where Item_Name = '" + name + "'\n" +
                                "  and Delivery_City = '" + city + "'\n" +
                                "  and Delivery_Courier = '" + log.name() + "'").next();
                        boolean courier = statement.executeQuery("select *\n" +
                                "from item\n" +
                                "         join Delivery D on Item.Item_Name = D.Delivery_Item\n" +
                                "where Item_Name = '" + name + "'\n" +
                                "  and Delivery_City = '" + city + "'\n" +
                                "  and Delivery_Courier is null ").next();
                        if (courier) {
                            if (s.equals(ItemState.FromImportTransporting)) {
                                statement.executeUpdate("update Delivery\n" +
                                        "set Delivery_Courier = '" + log.name() + "'\n" +
                                        "where Delivery_Item = '" + name + "");
                                con.commit();
                                return true;
                            } else return false;
                        } else if (exist1) {
                            ResultSet state2 = statement.executeQuery("select Item_State\n" +
                                    "from item\n" +
                                    "         join Retrieval R on Item.Item_Name = R.Retrieval_Item\n" +
                                    "where Retrieval_Courier = '" + log.name() + "'\n" +
                                    "  and Item_Name = '" + name + "'");
                            state2.next();
                            String state = state2.getString(1);
                            if (state.equals("From-Import Transporting") && s.equals(ItemState.Delivering)) {
                                statement.executeUpdate("update Item\n" +
                                        "set Item_State = 'Delivering'\n" +
                                        "where Item_Name = '" + name + "'");
                                con.commit();
                                return true;
                            } else if (state.equals("Delivering") && s.equals(ItemState.Finish)) {
                                statement.executeUpdate("update Item\n" +
                                        "set Item_State = 'Finish'\n" +
                                        "where Item_Name = '" + name + "'");
                                con.commit();
                                return true;
                            } else return false;
                        } else return false;

                    }
                }
            }
//            ATTENTION
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    @Override
    public String[] getAllItemsAtPort(LogInfo log) {
        ResultSet resultSet;

        try {
            if (!check_SeaportOfficer(log)) {
                return null;
            } else {
                getConnection(user, password);
                Statement Statement = con.createStatement();
                ResultSet Seaport = Statement.executeQuery("select Officer_City " +
                        "from Seaport_Officer " +
                        "where Officer_Name = '" + log.name() + "'");
                Seaport.next();
                String port = Seaport.getString(1);
                closeConnection();

                getConnection("seaportofficer", "2");
                Statement statement = con.createStatement();
                resultSet = statement.executeQuery("select Item_Name\n" +
                        "from (select *\n" +
                        "      from Item\n" +
                        "               join Export E on Item.Item_Name = E.Export_Item) A\n" +
                        "         join Import on A.Item_Name = Import.Import_Item\n" +
                        "where (A.Export_City = '" + port + "' and Item_State = 'Export Checking')\n" +
                        "   or (Import_City = '" + port + "' and Item_State = 'Import Checking')"
                );
                if (!resultSet.next()) {
                    return new String[0];
                } else {
                    ArrayList<String> arrayList = new ArrayList<>();
                    do {
                        arrayList.add(resultSet.getString(1));
                    } while (resultSet.next());
                    String[] AllItem = new String[arrayList.size()];
                    for (int i = 0; i < arrayList.size(); i++) {
                        AllItem[i] = arrayList.get(i);
                    }
                    return AllItem;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            closeConnection();
        }
    }

    @Override
    public boolean setItemCheckState(LogInfo log, String itemName, boolean success) {
        ResultSet resultSet;
        try {
            if (!check_SeaportOfficer(log)) {
                return false;
            } else {
                getConnection(user, password);
                Statement Statement = con.createStatement();
                ResultSet Seaport = Statement.executeQuery("select Officer_City " +
                        "from Seaport_Officer " +
                        "where Officer_Name = '" + log.name() + "'");
                Seaport.next();
                String port = Seaport.getString(1);
                closeConnection();

                getConnection("seaportofficer", "2");
                Statement statement = con.createStatement();
                resultSet = statement.executeQuery("select Item_State\n" +
                        "from (select *\n" +
                        "      from Item\n" +
                        "               join Export E on Item.Item_Name = E.Export_Item) A\n" +
                        "         join Import on A.Item_Name = Import.Import_Item\n" +
                        "where ((A.Export_City = '" + port + "' and Item_State = 'Export Checking')\n" +
                        "   or (Import_City = '" + port + "' and Item_State = 'Import Checking'))\n" +
                        "and Item_Name = '" + itemName + "'"
                );
                if (!resultSet.next()) {
                    return false;
                } else {
                    if (resultSet.getString(1).equals("Export Checking")) {
                        if (success) {
                            statement.executeUpdate("update Item set Item_State = 'Packing to Container' where Item_Name = '" + itemName + "'");
                        } else {
                            statement.executeUpdate("update Item set Item_State = 'Export Checking Fail' where Item_Name = '" + itemName + "'");
                        }
                        statement.executeUpdate("update Export set Export_Officer = '" + log.name() + "' where Export_Item = '" + itemName + "'");
                    } else {
                        if (success) {
                            statement.executeUpdate("update Item set Item_State = 'From-Import Transporting' where Item_Name = '" + itemName + "'");
                        } else {
                            statement.executeUpdate("update Item set Item_State = 'Import Checking Fail' where Item_Name = '" + itemName + "'");
                        }
                        statement.executeUpdate("update Import set Import_Officer = '" + log.name() + "' where Import_Item = '" + itemName + "'");
                    }
                    con.commit();
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    @Override
    public int getCompanyCount(LogInfo log) {
        try {
            if (!check_SUSTCDepartmentManager(log)) {
                return -1;
            } else {
                getConnection("sustc_department_manager", "4");
                Statement statement = con.createStatement();
                ResultSet resultSet = statement.executeQuery("select count( distinct item_company)\n" +
                        "from item");
                resultSet.next();
                return Integer.parseInt(resultSet.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        } finally {
            closeConnection();
        }
    }

    @Override
    public int getCityCount(LogInfo log) {
        try {
            if (!check_SUSTCDepartmentManager(log)) {
                return -1;
            } else {
                getConnection("sustc_department_manager", "4");
                Statement statement = con.createStatement();
                ResultSet resultSet1 = statement.executeQuery("select count( distinct retrieval_city)\n" +
                        "from retrieval;");
                resultSet1.next();
                int city1 = Integer.parseInt(resultSet1.getString(1));
                ResultSet resultSet2 = statement.executeQuery("select count( distinct delivery_city)\n" +
                        "from delivery;\n");
                resultSet2.next();
                int city2 = Integer.parseInt(resultSet2.getString(1));
                return city1 + city2;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        } finally {
            closeConnection();
        }
    }

    @Override
    public int getCourierCount(LogInfo log) {
        try {
            if (!check_SUSTCDepartmentManager(log)) {
                return -1;
            } else {
                getConnection("sustc_department_manager", "4");
                Statement statement = con.createStatement();
                ResultSet resultSet = statement.executeQuery("select count(*)\n" +
                        "from Courier");
                resultSet.next();
                return Integer.parseInt(resultSet.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        } finally {
            closeConnection();
        }
    }

    @Override
    public int getShipCount(LogInfo log) {
        try {
            if (!check_SUSTCDepartmentManager(log)) {
                return -1;
            } else {
                getConnection("sustc_department_manager", "4");
                Statement statement = con.createStatement();
                ResultSet resultSet = statement.executeQuery("select count(distinct ship_name)\n" +
                        "from shipping");
                resultSet.next();
                return Integer.parseInt(resultSet.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        } finally {
            closeConnection();
        }
    }

    @Override
    public ItemInfo getItemInfo(LogInfo log, String name) {
        try {
            if (!check_SUSTCDepartmentManager(log)) {
                return null;
            } else {
                getConnection("sustc_department_manager", "4");
                Statement statement = con.createStatement();
                ResultSet check = statement.executeQuery("select * from Item where Item_Name = '" + name + "'");
                if (!check.next()) {
                    return null;
                } else {
                    ResultSet resultSet1 = statement.executeQuery("select * from Retrieval where Retrieval_Item = '" + name + "'");
                    resultSet1.next();
                    ItemInfo.RetrievalDeliveryInfo retrieval = new ItemInfo.RetrievalDeliveryInfo(resultSet1.getString(3), resultSet1.getString(2));

                    ResultSet resultSet2 = statement.executeQuery("select * from Delivery where Delivery_Item = '" + name + "'");
                    resultSet2.next();
                    ItemInfo.RetrievalDeliveryInfo delivery = new ItemInfo.RetrievalDeliveryInfo(resultSet2.getString(3), resultSet2.getString(2));

                    ResultSet resultSet3 = statement.executeQuery("select * from Import where Import_Item = '" + name + "'");
                    resultSet3.next();
                    ItemInfo.ImportExportInfo $import = new ItemInfo.ImportExportInfo(resultSet3.getString(3), resultSet3.getString(4), Double.parseDouble(resultSet3.getString(2)));

                    ResultSet resultSet4 = statement.executeQuery("select * from Export where Export_Item = '" + name + "'");
                    resultSet4.next();
                    ItemInfo.ImportExportInfo export = new ItemInfo.ImportExportInfo(resultSet4.getString(3), resultSet4.getString(4), Double.parseDouble(resultSet4.getString(2)));

                    ResultSet resultSet = statement.executeQuery("select * from Item where Item_Name = '" + name + "'");
                    resultSet.next();
                    ItemState state = null;
                    switch (resultSet.getString(4)) {
                        case "Finish":
                            state = ItemState.Finish;
                            break;
                        case "Import Check Fail":
                            state = ItemState.ImportCheckFailed;
                            break;
                        case "Unpacking from Container":
                            state = ItemState.UnpackingFromContainer;
                            break;
                        case "From-Import Transporting":
                            state = ItemState.FromImportTransporting;
                            break;
                        case "Export Check Fail":
                            state = ItemState.ExportCheckFailed;
                            break;
                        case "To-Export Transporting":
                            state = ItemState.ToExportTransporting;
                            break;
                        case "Import Checking":
                            state = ItemState.ImportChecking;
                            break;
                        case "Picking-up":
                            state = ItemState.PickingUp;
                            break;
                        case "Packing to Container":
                            state = ItemState.PackingToContainer;
                            break;
                        case "Waiting for Shipping":
                            state = ItemState.WaitingForShipping;
                            break;
                        case "Shipping":
                            state = ItemState.Shipping;
                            break;
                        case "Delivering":
                            state = ItemState.Delivering;
                            break;
                        case "Export Checking":
                            state = ItemState.ExportChecking;
                            break;
                    }
                    return new ItemInfo(name, resultSet.getString(3), Double.parseDouble(resultSet.getString(2)), state, retrieval, delivery, $import, export);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            closeConnection();
        }
    }

    @Override
    public ShipInfo getShipInfo(LogInfo log, String name) {
        try {
            if (!check_SUSTCDepartmentManager(log)) {
                return null;
            } else {
                getConnection("sustc_department_manager", "4");
                Statement statement = con.createStatement();
                ResultSet check = statement.executeQuery("select distinct ship_name, item_company\n" +
                        "from item join shipping on item.item_name = shipping.shipping_item\n" +
                        "where ship_name = '" + name + "'\n" +
                        "group by ship_name, item_company");
                if (!check.next()) {
                    return null;
                } else {
                    String owner = check.getString(2);
                    ResultSet sailing = statement.executeQuery("\n" +
                            "select distinct item_state\n" +
                            "from item join shipping on item.item_name = shipping.shipping_item\n" +
                            "where ship_name = '" + name + "' AND item_state = 'Shipping'");
                    boolean sailing_state;
                    sailing_state = sailing.next();
                    return new ShipInfo(name, owner, sailing_state);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            closeConnection();
        }
    }

    @Override
    public ContainerInfo getContainerInfo(LogInfo log, String code) {
        try {
            if (!check_SUSTCDepartmentManager(log)) {
                return null;
            } else {
                getConnection("sustc_department_manager", "4");
                Statement statement = con.createStatement();
                boolean exist = statement.executeQuery("select * from containing where Container_Code = '" + code + "'").next();
                if (exist) {
                    ResultSet resultSet = statement.executeQuery("select * from containing where Container_Code = '" + code + "'");
                    resultSet.next();
                    ContainerInfo.Type type = null;
                    switch (resultSet.getString(3)) {
                        case "Dry Container":
                            type = ContainerInfo.Type.Dry;
                            break;
                        case "ISO Tank Container":
                            type = ContainerInfo.Type.ISOTank;
                            break;
                        case "Open Top Container":
                            type = ContainerInfo.Type.OpenTop;
                            break;
                        case "Flat Rack Container":
                            type = ContainerInfo.Type.FlatRack;
                            break;
                        case "Reefer Container":
                            type = ContainerInfo.Type.Reefer;
                            break;
                    }
                    boolean using = statement.executeQuery("select *\n" +
                            "from Containing\n" +
                            "         join Item I on I.Item_Name = Containing_Item\n" +
                            "where (Item_State = 'Waiting for Shipping' or Item_State = 'Shipping' or Item_State = 'Unpacking from Container')\n" +
                            "  and Container_Code = '" + code + "'").next();

                    return new ContainerInfo(type, code, using);
                } else return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            closeConnection();
        }
    }

    @Override
    public StaffInfo getStaffInfo(LogInfo log, String name) {
        try {
            if (!check_SUSTCDepartmentManager(log)) {
                return null;
            } else {
                getConnection("sustc_department_manager", "4");
                Statement statement = con.createStatement();
                LogInfo basicInfo;
//                String name;
                // name is the method parameter
                LogInfo.StaffType type;
                String password;
                String company = null;
                String city = null;
                boolean isFemale;
                int age;
                String phoneNumber;
                ResultSet courier_result = statement.executeQuery("select *\n" +
                        "from courier\n" +
                        "where courier_name = '" + name + "'");
                if (courier_result.next()) {
                    type = LogInfo.StaffType.Courier;
                    age = courier_result.getInt(3);
                    // getInt ?
                    isFemale = courier_result.getString(4).equals("female");
                    phoneNumber = courier_result.getString(5);
                    city = courier_result.getString(6);
                    company = courier_result.getString(7);
                    password = courier_result.getString(8);
                    basicInfo = new LogInfo(name, type, password);
                } else {
                    ResultSet company_manager_result = statement.executeQuery("select *\n" +
                            "from company_manager\n" +
                            "where manager_name = '" + name + "'");
                    if (company_manager_result.next()) {
                        type = LogInfo.StaffType.CompanyManager;
                        age = company_manager_result.getInt(3);
                        // getInt?
                        isFemale = company_manager_result.getString(4).equals("female");
                        phoneNumber = company_manager_result.getString(5);
                        company = company_manager_result.getString(6);
                        password = company_manager_result.getString(7);
                        basicInfo = new LogInfo(name, type, password);
                    } else {
                        ResultSet department_manager_result = statement.executeQuery("select *\n" +
                                "from sustc_department_manager\n" +
                                "where manager_name = '" + name + "'");
                        if (department_manager_result.next()) {
                            type = LogInfo.StaffType.SustcManager;
                            age = department_manager_result.getInt(3);
                            isFemale = department_manager_result.getString(4).equals("female");
                            phoneNumber = department_manager_result.getString(5);
                            password = department_manager_result.getString(6);
                            basicInfo = new LogInfo(name, type, password);
                        } else {
                            ResultSet seaport_officer_result = statement.executeQuery("select *\n" +
                                    "from seaport_officer\n" +
                                    "where officer_name = '" + name + "'");
                            type = LogInfo.StaffType.SeaportOfficer;
                            seaport_officer_result.next();
                            age = seaport_officer_result.getInt(3);
                            isFemale = seaport_officer_result.getString(4).equals("female");
                            phoneNumber = seaport_officer_result.getString(5);
                            city = seaport_officer_result.getString(6);
                            password = seaport_officer_result.getString(7);
                            basicInfo = new LogInfo(name, type, password);
                        }
                    }
                }
                return new StaffInfo(basicInfo, company, city, isFemale, age, phoneNumber);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            closeConnection();
        }
    }

    public void getConnection(String user, String password) {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (Exception e) {
            System.err.println("Cannot find the PostgreSQL driver. Check CLASSPATH.");
            System.exit(1);
        }

        try {
            String url = DatabaseManipulation.url;
            con = DriverManager.getConnection(url, user, password);
            con.setAutoCommit(false);
        } catch (SQLException e) {
            System.err.println("Database connection failed");
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }

    public void closeConnection() {
        if (con != null) {
            try {
                con.close();
                con = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public boolean check_SeaportOfficer(LogInfo logInfo) {
        getConnection(user, password);
        ResultSet checkInfo;
        try {
            Statement statement = con.createStatement();
            checkInfo = statement.executeQuery("select * " +
                    "from Seaport_Officer " +
                    "where Officer_Name = '" + logInfo.name() + "' " +
                    "  and Officer_Password = '" + logInfo.password() + "'");
            if (!checkInfo.next()) {
                return false;
            } else return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    public boolean check_Courier(LogInfo logInfo) {
        getConnection(user, password);
        ResultSet checkInfo;

        try {
            Statement statement = con.createStatement();
            checkInfo = statement.executeQuery("select * " +
                    "from Courier " +
                    "where Courier_Name = '" + logInfo.name() + "' " +
                    "  and Courier_Password = '" + logInfo.password() + "'");
            if (!checkInfo.next()) {
                return false;
            } else return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    public boolean check_CompanyManager(LogInfo logInfo) {
        getConnection(user, password);
        ResultSet checkInfo;

        try {
            Statement statement = con.createStatement();
            checkInfo = statement.executeQuery("select * " +
                    "from Company_Manager " +
                    "where Manager_Name = '" + logInfo.name() + "' " +
                    "  and Manager_Password = '" + logInfo.password() + "'");
            if (!checkInfo.next()) {
                return false;
            } else return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }

    public boolean check_SUSTCDepartmentManager(LogInfo logInfo) {
        getConnection(user, password);
        ResultSet checkInfo;

        try {
            Statement statement = con.createStatement();
            checkInfo = statement.executeQuery("select * " +
                    "from SUSTC_Department_Manager " +
                    "where Manager_Name = '" + logInfo.name() + "' " +
                    "  and Manager_Password = '" + logInfo.password() + "'");
            if (!checkInfo.next()) {
                return false;
            } else return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection();
        }
    }
}

