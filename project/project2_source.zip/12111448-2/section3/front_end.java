package main;

import main.DatabaseManipulation;
import main.interfaces.ItemInfo;
import main.interfaces.ItemState;
import main.interfaces.LogInfo;

import java.util.Scanner;

public class front_end {
    public static void main(String[] args) {
        String database = "localhost:5432/postgres";
        String root_name = "slina";
        String root_password = "123456";
        String read_new_line;
        DatabaseManipulation test =
                new DatabaseManipulation(database, root_name, root_password);
        database_status status =null;
        LogInfo current_user = null;
        Scanner sc = new Scanner(System.in);
        System.out.println("Please choose the begin state: ");
        System.out.println("[1] choose_user");
        System.out.println("[2] exit");
        int start_state = sc.nextInt();
        read_new_line = sc.nextLine();
        switch (start_state) {
            case 1: status = database_status.change_user;
                break;
            case 2: status = database_status.exit;
                break;
        };
        while (status != database_status.exit) {
            if (status == database_status.change_user) {
                current_user = input_logInfo();
                status = database_status.do_operation;
            }
            switch (current_user.type()) {
                case SustcManager: {
                    System.out.println("Please choose the operation: ");
                    System.out.println("[1] getCompanyCount");
                    System.out.println("[2] getCityCount");
                    System.out.println("[3] getCourierCount");
                    System.out.println("[4] getShipCount");
                    System.out.println("[5] getItemInfo");
                    System.out.println("[6] getShipCount");
                    System.out.println("[7] getContainerInfo");
                    System.out.println("[8] getStaffInfo");
                    int operation = sc.nextInt();
                    read_new_line = sc.nextLine();
                    switch (operation) {
                        case 1:
                            System.out.println(test.getCompanyCount(current_user));
                            break;
                        case 2:
                            System.out.println(test.getCityCount(current_user));
                            break;
                        case 3:
                            System.out.println(test.getCourierCount(current_user));
                            break;
                        case 4:
                            System.out.println(test.getShipCount(current_user));
                            break;
                        case 5:
                            System.out.println("Please enter the item name: ");
                            String itemName = sc.nextLine();
                            System.out.println(test.getItemInfo(current_user, itemName));
                            break;
                        case 6:
                            System.out.println("Please enter the ship name: ");
                            String shipName = sc.nextLine();
                            System.out.println(test.getShipInfo(current_user, shipName));
                            break;
                        case 7:
                            System.out.println("Please enter the container name: ");
                            String containerName = sc.nextLine();
                            System.out.println(test.getContainerInfo(current_user, containerName));
                            break;
                        case 8:
                            System.out.println("Please enter the staff name: ");
                            String staffName = sc.nextLine();
                            System.out.println(test.getStaffInfo(current_user, staffName));
                            break;
                    }
                    break;
                }
                case CompanyManager: {
                    System.out.println("Please choose the operation: ");
                    System.out.println("[1] getImportTaxRate");
                    System.out.println("[2] getExportTaxRate");
                    System.out.println("[3] loadItemToContainer");
                    System.out.println("[4] loadContainerToShip");
                    System.out.println("[5] shipStartSailing");
                    System.out.println("[6] unloadItem");
                    System.out.println("[7] itemWaitForChecking");
                    int operation = sc.nextInt();
                    read_new_line = sc.nextLine();
                    switch (operation) {
                        case 1:
                            System.out.println("Please enter the city name: ");
                            String cityName = sc.nextLine();
                            System.out.println("Please enter the itemClass");
                            String itemClass = sc.nextLine();
                            System.out.println(test.getImportTaxRate(current_user, cityName, itemClass));
                            break;
                        case 2:
                            System.out.println("Please enter the city name: ");
                            cityName = sc.nextLine();
                            System.out.println("Please enter the itemClass");
                            itemClass = sc.nextLine();
                            System.out.println(test.getExportTaxRate(current_user, cityName, itemClass));
                            break;
                        case 3:
                            System.out.println("Please enter the item name: ");
                            String itemName = sc.nextLine();
                            System.out.println("Please enter the container code: ");
                            String containerCode = sc.nextLine();
                            System.out.println(test.loadItemToContainer(current_user, itemName, containerCode));
                            break;
                        case 4:
                            System.out.println("Please enter the ship name: ");
                            String shipName = sc.nextLine();
                            System.out.println("Please enter the container code: ");
                            containerCode = sc.nextLine();
                            System.out.println(test.loadContainerToShip(current_user, shipName, containerCode));
                            break;
                        case 5:
                            System.out.println("Please enter the ship name: ");
                            shipName = sc.nextLine();
                            System.out.println(test.shipStartSailing(current_user, shipName));
                            break;
                        case 6:
                            System.out.println("Please enter the item name: ");
                            itemName = sc.nextLine();
                            System.out.println(test.unloadItem(current_user, itemName));
                            break;
                        case 7:
                            System.out.println("Please enter the item name: ");
                            itemName = sc.nextLine();
                            System.out.println(test.itemWaitForChecking(current_user, itemName));
                            break;
                    }
                    break;
                }
                case Courier: {
                    System.out.println("Please choose the operation: ");
                    System.out.println("[1] newItem");
                    System.out.println("[2] setItemState");
                    int operation = sc.nextInt();
                    read_new_line = sc.nextLine();
                    switch (operation) {
                        case 1: {
                            System.out.println("Please enter the item name: ");
                            String name = sc.nextLine();
                            System.out.println("Please enter the item class :");
                            String itemClass = sc.nextLine();
                            System.out.println("Please enter the price :");
                            Double price = sc.nextDouble();
                            read_new_line = sc.nextLine();
                            System.out.println("Please enter the item state :");
                            System.out.println("PickingUp,\n" +
                                    "ToExportTransporting,\n" +
                                    "ExportChecking,\n" +
                                    "ExportCheckFailed,\n" +
                                    "PackingToContainer,\n" +
                                    "WaitingForShipping,\n" +
                                    "Shipping,\n" +
                                    "UnpackingFromContainer,\n" +
                                    "ImportChecking,\n" +
                                    "ImportCheckFailed,\n" +
                                    "FromImportTransporting,\n" +
                                    "Delivering,\n" +
                                    "Finish");

                            String state_input = sc.nextLine();
                            ItemState state = null;
                            switch (state_input) {
                                case "PickingUp":
                                    state = ItemState.PickingUp;
                                    break;
                                case "ToExportTransporting":
                                    state = ItemState.ToExportTransporting;
                                    break;
                                case "ExportChecking":
                                    state = ItemState.ExportChecking;
                                    break;
                                case "ExportCheckFailed":
                                    state = ItemState.ExportCheckFailed;
                                    break;
                                case "PackingToContainer":
                                    state = ItemState.PackingToContainer;
                                    break;
                                case "WaitingForShipping":
                                    state = ItemState.WaitingForShipping;
                                    break;
                                case "Shipping":
                                    state = ItemState.Shipping;
                                    break;
                                case "UnpackingFromContainer":
                                    state = ItemState.UnpackingFromContainer;
                                    break;
                                case "ImportChecking":
                                    state = ItemState.ImportChecking;
                                    break;
                                case "ImportCheckFailed":
                                    state = ItemState.ImportCheckFailed;
                                    break;
                                case "FromImportTransporting":
                                    state = ItemState.FromImportTransporting;
                                    break;
                                case "Delivering":
                                    state = ItemState.Delivering;
                                    break;
                                case "Finish":
                                    state = ItemState.Finish;
                                    break;
                            }
                            System.out.println("Please enter the retrieval city:");
                            String retrieval_city = sc.nextLine();
                            System.out.println("Please enter the retrieval courier:");
                            String retrieval_courier = sc.nextLine();
                            System.out.println("Please enter the delivery city:");
                            String delivery_city = sc.nextLine();
                            System.out.println("Please enter the delivery courier:");
                            String delivery_courier = sc.nextLine();
                            System.out.println("Please enter the export city:");
                            String export_city = sc.nextLine();
                            System.out.println("Please enter the export officer:");
                            String export_officer = sc.nextLine();
                            System.out.println("Please enter the export tax:");
                            double export_tax = sc.nextDouble();
                            read_new_line = sc.nextLine();
                            System.out.println("Please enter the import city:");
                            String import_city = sc.nextLine();
                            System.out.println("Please enter the import officer:");
                            String import_officer = sc.nextLine();
                            System.out.println("Please enter the import tax:");
                            double import_tax = sc.nextDouble();
                            read_new_line = sc.nextLine();
                            ItemInfo.ImportExportInfo import_info
                                    = new ItemInfo.ImportExportInfo(import_city, import_officer, import_tax);
                            ItemInfo.ImportExportInfo export_info
                                    = new ItemInfo.ImportExportInfo(export_city, export_officer, export_tax);
                            ItemInfo.RetrievalDeliveryInfo retrieval_info
                                    = new ItemInfo.RetrievalDeliveryInfo(retrieval_city, retrieval_courier);
                            ItemInfo.RetrievalDeliveryInfo delivery_info
                                    = new ItemInfo.RetrievalDeliveryInfo(delivery_city, delivery_courier);
                            ItemInfo item_info
                                    = new ItemInfo(name, itemClass, price, state,
                                    retrieval_info, delivery_info, import_info, export_info);
                            System.out.println(test.newItem(current_user, item_info));
                            break;
                        }
                        case 2: {
                            System.out.println("Please enter the item name:");
                            String item_name = sc.nextLine();
                            System.out.println("Please enter the item state :");
                            System.out.println("PickingUp,\n" +
                                    "\tToExportTransporting,\n" +
                                    "\tExportChecking,\n" +
                                    "\tExportCheckFailed,\n" +
                                    "\tPackingToContainer,\n" +
                                    "\tWaitingForShipping,\n" +
                                    "\tShipping,\n" +
                                    "\tUnpackingFromContainer,\n" +
                                    "\tImportChecking,\n" +
                                    "\tImportCheckFailed,\n" +
                                    "\tFromImportTransporting,\n" +
                                    "\tDelivering,\n" +
                                    "\tFinish");
                            String state_input = sc.nextLine();
                            ItemState state = null;
                            switch (state_input) {
                                case "PickingUp":
                                    state = ItemState.PickingUp;
                                    break;
                                case "ToExportTransporting":
                                    state = ItemState.ToExportTransporting;
                                    break;
                                case "ExportChecking":
                                    state = ItemState.ExportChecking;
                                    break;
                                case "ExportCheckFailed":
                                    state = ItemState.ExportCheckFailed;
                                    break;
                                case "PackingToContainer":
                                    state = ItemState.PackingToContainer;
                                    break;
                                case "WaitingForShipping":
                                    state = ItemState.WaitingForShipping;
                                    break;
                                case "Shipping":
                                    state = ItemState.Shipping;
                                    break;
                                case "UnpackingFromContainer":
                                    state = ItemState.UnpackingFromContainer;
                                    break;
                                case "ImportChecking":
                                    state = ItemState.ImportChecking;
                                    break;
                                case "ImportCheckFailed":
                                    state = ItemState.ImportCheckFailed;
                                    break;
                                case "FromImportTransporting":
                                    state = ItemState.FromImportTransporting;
                                    break;
                                case "Delivering":
                                    state = ItemState.Delivering;
                                    break;
                                case "Finish":
                                    state = ItemState.Finish;
                                    break;
                            }
                            System.out.println(test.setItemState(current_user, item_name, state));
                            break;
                        }
                    }
                    break;
                }
                case SeaportOfficer:{
                    System.out.println("Please choose the operation: ");
                    System.out.println("[1] getAllItemAtPort");
                    System.out.println("[2] setItemCheckState");
                    int operation = sc.nextInt();
                    read_new_line = sc.nextLine();
                    switch (operation) {
                        case 1: {
                            System.out.println(test.getAllItemsAtPort(current_user));
                            break;
                        }
                        case 2: {
                            System.out.println("Please enter the item name: ");
                            String item_name = sc.nextLine();
                            System.out.println("Please enter the checking state(1/0): ");
                            int checking_state = sc.nextInt();
                            read_new_line = sc.nextLine();
                            boolean success= checking_state == 1;
                            System.out.println(test.setItemCheckState(current_user,item_name,success));
                            break;
                        }
                    }
                    break;
                }
            }
            System.out.println("Please choose the next state: ");
            System.out.println("[1] change_user");
            System.out.println("[2] do_operation");
            System.out.println("[3] exit");
            int state = sc.nextInt();
            read_new_line = sc.nextLine();
            switch (state) {
                case 1: status = database_status.change_user;
                    break;
                case 2: status = database_status.do_operation;
                    break;
                case 3: status = database_status.exit;
                    break;
            };
        }
        System.out.println("Exit successfully!");
    }
    public static LogInfo input_logInfo () {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please choose the authorization type: ");
        System.out.println("[1] Courier");
        System.out.println("[2] Company Manager");
        System.out.println("[3] Seaport Officer");
        System.out.println("[4] SUSTC Department Manager");
        int choice = sc.nextInt();
        String readNewLine = sc.nextLine();
        System.out.println("Please enter the user name: ");
        String user_name = sc.nextLine();
        System.out.println("Please enter the password: ");
        String user_password = sc.nextLine();
        return switch (choice) {
            case 1 -> new LogInfo(user_name, LogInfo.StaffType.Courier, user_password);
            case 2 -> new LogInfo(user_name, LogInfo.StaffType.CompanyManager, user_password);
            case 3 -> new LogInfo(user_name, LogInfo.StaffType.SeaportOfficer, user_password);
            case 4 -> new LogInfo(user_name, LogInfo.StaffType.SustcManager, user_password);
            default -> null;
        };
    }
    public enum database_status {
        change_user,
        do_operation,
        exit
    }
}

